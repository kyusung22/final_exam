합계 4
-rw-r--rw- 1 root pi    0  9월  8 11:27 file1.txt
-rw-r-xr-- 1 pi   pi    0  9월  8 11:27 file2.txt
drwxr-xr-x 2 pi   pi 4096  9월  8 11:29 folder
-rw-r--r-- 1 pi   pi    0  9월  8 13:39 readme.txt
file1.txt
file2.txt
folder
readme.txt
