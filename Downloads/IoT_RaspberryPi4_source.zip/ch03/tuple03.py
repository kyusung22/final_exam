card = 'red', 4, 'python', True
a ,b, c, d = card
print(a) 
print(b) 
print(c) 
d = False
print(d)