a, b, c, d = 0, 0, 0, 0
hap = 0
a = int(input("1번째 숫자 : "))
b = int(input("2번째 숫자 : "))
c = int(input("3번째 숫자 : "))
d = int(input("4번째 숫자 : "))
hap = a + b + c + d

print("합계 ==> %d" % hap)
