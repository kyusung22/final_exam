a = True
print(type(a))
a = (100==100)
print(a)
b = (10>100)
print(a, b)