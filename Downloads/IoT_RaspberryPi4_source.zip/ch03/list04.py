aa = [10, 20, 30, 40]
print("aa[-1]은 %d, aa[-2]는 %d" % (aa[-1], aa[-2]))
print(aa[0:2])
print(aa[2:4])
print(aa[0:])
