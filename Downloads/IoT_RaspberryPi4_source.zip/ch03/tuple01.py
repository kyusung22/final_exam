str = "파이썬 문자열"
print(str[0])
print(str[-1])
#str[-1] = '렬'

card = 'red', 4, 'python', True
print(card)
print(card[1])
#card[0] = 'blue'
