a = 123
print(type(a))
a = 100 * 100
print(a)
a , b = 9 , 2
print(a * b)
